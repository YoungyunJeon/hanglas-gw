dsnameList = [

    ["KISCO", ["#034 KISCO_DEV", "#034 KISCO_PRD_LNX", "#034 KISCO_PRD_WIN"]]
    
]


KISCO = [
    ["KISCO", ["#034 KISCO_DEV", "#034 KISCO_PRD_LNX", "#034 KISCO_PRD_WIN"]]
]

